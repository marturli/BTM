package academy.devdojo.springboot2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springboot2EssentialsApplicationTests {

	@Test
	void contextLoads() {
	}

}
