package academy.devdojo.springboot2.service;

import academy.devdojo.springboot2.domain.Musica;
import academy.devdojo.springboot2.mapper.MusicaMapper;
import academy.devdojo.springboot2.repository.MusicaRepository;
import academy.devdojo.springboot2.request.MusicaPostRequestBody;
import academy.devdojo.springboot2.request.MusicaPutRequestBody;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import lombok.RequiredArgsConstructor;

import java.util.List;

@Service
@RequiredArgsConstructor
public class MusicaService {
	private final MusicaRepository musicarepository;
	public List<Musica> listAll(){
		return musicarepository.findAll();
	}
	
	public Musica findByIdOrThrowBadRequestException(Long id) {
		return musicarepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST,"Musica not found"));
	}
	
	public Musica save(MusicaPostRequestBody musicapostrequestbody) {
		return  musicarepository.save(MusicaMapper.INSTANCE.toMusica(musicapostrequestbody));
	}
	
	public void delete (long id) {
		musicarepository.delete(findByIdOrThrowBadRequestException(id));
	}
	
	public void replace(MusicaPutRequestBody musicaputrequestbody) {
		Musica savedmusica = findByIdOrThrowBadRequestException(musicaputrequestbody.getId());
		Musica musica = MusicaMapper.INSTANCE.toMusica(musicaputrequestbody);
		musica.setId(savedmusica.getId());
		musicarepository.save(musica);
	}
}
