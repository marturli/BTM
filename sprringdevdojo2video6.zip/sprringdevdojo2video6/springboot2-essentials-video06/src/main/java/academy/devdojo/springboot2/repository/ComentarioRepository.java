package academy.devdojo.springboot2.repository;

import academy.devdojo.springboot2.domain.Comentario;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import lombok.RequiredArgsConstructor;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

@Service
@RequiredArgsConstructor
public class ComentarioRepository {
	private static List<Comentario> comentarios;
	
	static {
        comentarios = new ArrayList<>(List.of(new Comentario((long) 1D,"Show de bola","BiancaBianca","The Chainsmokers","A letra é emocionante"), new Comentario((long)2D,"Ruim de menos","Aliat","The Wanted","Não vou diizer que está bom mas tambem não está ruim"), new Comentario((long) 3D,"Sofrivel","Math","Hayley Kyoko","Uma batidda envolvente um clipe bem estruturado, um verdadeiro show de sabores. ")));
    }
	
	public List<Comentario> listAll(){
		return comentarios;
	}
	
	public Comentario findById(Long id) {
		return comentarios.stream()
				.filter(comentario -> comentario.getId().equals(id))
                .findFirst()
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST,"Comentario not found"));
	}
	
	public Comentario save(Comentario comentario) {
		comentario.setId(ThreadLocalRandom.current().nextLong(3,100000));
		comentarios.add(comentario);
		return comentario;
	}
	
	public void delete(long id) {
		comentarios.remove(findById(id));
	}
	
	public void replace(Comentario comentario) {
		delete(comentario.getId());
		comentarios.add(comentario);
	}
}
