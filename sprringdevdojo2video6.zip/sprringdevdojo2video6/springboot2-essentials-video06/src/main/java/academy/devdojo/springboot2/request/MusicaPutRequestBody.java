package academy.devdojo.springboot2.request;

import lombok.Data;

@Data
public class MusicaPutRequestBody {
	private Long id;
    private String nome;
    private String artista;
    private String lancamento;
    private String genero;
}
