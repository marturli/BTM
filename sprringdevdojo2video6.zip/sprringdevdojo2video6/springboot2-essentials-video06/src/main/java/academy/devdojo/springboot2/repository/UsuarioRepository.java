package academy.devdojo.springboot2.repository;

import academy.devdojo.springboot2.domain.Usuario;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import lombok.RequiredArgsConstructor;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

@Service
@RequiredArgsConstructor
public class UsuarioRepository {
	private static List<Usuario> usuarios;
	
	static {
        usuarios = new ArrayList<>(List.of(new Usuario((long) 1D,"Matheus","three@gmail.com","Math","Htam"), new Usuario((long)2D,"Bianca","Bibi@gmail.com","BiancaBianca","49222-8902"), new Usuario((long) 3D,"Taila","Tanattia@gmail.com","Aliat","Xoxacapenga")));
    }
	
	public List<Usuario> listAll(){
		return usuarios;
	}
	
	public Usuario findById(Long id) {
		return usuarios.stream()
				.filter(usuario -> usuario.getId().equals(id))
                .findFirst()
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST,"Usuario not found"));
	}
	
	public Usuario save(Usuario usuario) {
		usuario.setId(ThreadLocalRandom.current().nextLong(3,100000));
		usuarios.add(usuario);
		return usuario;
	}
	
	public void delete(long id) {
		usuarios.remove(findById(id));
	}
	
	public void replace(Usuario usuario) {
		delete(usuario.getId());
		usuarios.add(usuario);
	}
}
