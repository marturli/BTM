package academy.devdojo.springboot2.controller;

import academy.devdojo.springboot2.domain.Usuario;
import academy.devdojo.springboot2.service.UsuarioService;
import lombok.RequiredArgsConstructor;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("usuario")
@RequiredArgsConstructor
public class UsuarioController {
	private final UsuarioService usuarioservice;
	
	@GetMapping
    public ResponseEntity<List<Usuario>> list(){
        return ResponseEntity.ok(usuarioservice.listAll());
    }
	
	@GetMapping(path = "/{id}")
	public ResponseEntity<Usuario> findById(@PathVariable long id){
		return ResponseEntity.ok(usuarioservice.findById(id));
	}
	
	@PostMapping
	public ResponseEntity<Usuario> save(@RequestBody Usuario usuario){
		return new ResponseEntity<>(usuarioservice.save(usuario), HttpStatus.CREATED);
	}

	@DeleteMapping(path = "/{id}")
	public ResponseEntity<Void> delete(@PathVariable long id){
		usuarioservice.delete(id);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
	
	@PutMapping
	public ResponseEntity<Void> replace(@RequestBody Usuario usuario){
		usuarioservice.replace(usuario);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
}
