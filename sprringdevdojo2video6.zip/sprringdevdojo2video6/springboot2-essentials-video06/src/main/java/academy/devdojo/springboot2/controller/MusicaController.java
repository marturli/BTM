package academy.devdojo.springboot2.controller;

import academy.devdojo.springboot2.domain.Musica;
import academy.devdojo.springboot2.service.MusicaService;
import academy.devdojo.springboot2.request.MusicaPostRequestBody;
import academy.devdojo.springboot2.request.MusicaPutRequestBody;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;



import java.util.List;

@RestController
@RequestMapping("musica")
@Log4j2
@RequiredArgsConstructor
public class MusicaController {
private final MusicaService musicaservice;
	
    @GetMapping
    public ResponseEntity<List<Musica>> list(){
    	return ResponseEntity.ok(musicaservice.listAll());
    }
    
	  @GetMapping(path = "/{id}")
    public ResponseEntity<Musica> findById(@PathVariable long id){
    	return ResponseEntity.ok(musicaservice.findByIdOrThrowBadRequestException(id));
    }   
    
    @PostMapping
    public ResponseEntity<Musica> save(@RequestBody MusicaPostRequestBody musicapostrequestbody){
    	return new ResponseEntity<>(musicaservice.save(musicapostrequestbody), HttpStatus.CREATED);
    }
	
	@DeleteMapping(path = "/{id}")
	public ResponseEntity<Void> delete(@PathVariable long id){
		musicaservice.delete(id);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
	
	@PutMapping
	public ResponseEntity<Void> replace(@RequestBody MusicaPutRequestBody musicaputrequestbody){
		musicaservice.replace(musicaputrequestbody);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
}
