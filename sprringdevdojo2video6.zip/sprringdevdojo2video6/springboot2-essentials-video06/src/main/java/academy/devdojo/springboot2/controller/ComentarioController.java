package academy.devdojo.springboot2.controller;

import academy.devdojo.springboot2.domain.Comentario;
import academy.devdojo.springboot2.service.ComentarioService;
import lombok.RequiredArgsConstructor;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("comentario")
@RequiredArgsConstructor
public class ComentarioController {
	private final ComentarioService comentarioservice;
	
	@GetMapping
    public ResponseEntity<List<Comentario>> list(){
        return ResponseEntity.ok(comentarioservice.listAll());
    }
	
	@GetMapping(path = "/{id}")
	public ResponseEntity<Comentario> findById(@PathVariable long id){
		return ResponseEntity.ok(comentarioservice.findById(id));
	}
	
	@PostMapping
	public ResponseEntity<Comentario> save(@RequestBody Comentario comentario){
		return new ResponseEntity<>(comentarioservice.save(comentario), HttpStatus.CREATED);
	}

	@DeleteMapping(path = "/{id}")
	public ResponseEntity<Void> delete(@PathVariable long id){
		comentarioservice.delete(id);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
	
	@PutMapping
	public ResponseEntity<Void> replace(@RequestBody Comentario comentario){
		comentarioservice.replace(comentario);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}

}
