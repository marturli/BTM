package academy.devdojo.springboot2.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import academy.devdojo.springboot2.domain.Musica;
import academy.devdojo.springboot2.request.MusicaPostRequestBody;
import academy.devdojo.springboot2.request.MusicaPutRequestBody;

@Mapper(componentModel = "spring")
public abstract class MusicaMapper {
	public static final MusicaMapper INSTANCE = Mappers.getMapper(MusicaMapper.class);
	public abstract Musica toMusica(MusicaPostRequestBody musicapostrequestbody);
	public abstract Musica toMusica(MusicaPutRequestBody musicaputrequestbody);
}
