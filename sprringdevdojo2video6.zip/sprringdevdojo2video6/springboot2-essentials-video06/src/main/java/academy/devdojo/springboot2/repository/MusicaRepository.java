package academy.devdojo.springboot2.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import academy.devdojo.springboot2.domain.Musica;;

public interface MusicaRepository extends JpaRepository<Musica, Long>{
    
}

