package academy.devdojo.springboot2.controller;

import academy.devdojo.springboot2.domain.Musica;
import academy.devdojo.springboot2.service.MusicaService;
import lombok.RequiredArgsConstructor;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;



import java.util.List;

@RestController
@RequestMapping("musica")
@RequiredArgsConstructor
public class MusicaController {
	private final MusicaService musicaservice;
	
	@GetMapping
    public ResponseEntity<List<Musica>> list(){
        return ResponseEntity.ok(musicaservice.listAll());
    }
	
	@GetMapping(path = "/{id}")
	public ResponseEntity<Musica> findById(@PathVariable long id){
		return ResponseEntity.ok(musicaservice.findById(id));
	}

}
